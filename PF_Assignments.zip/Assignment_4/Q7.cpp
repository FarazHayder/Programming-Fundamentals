#include <iostream>
#include <string>
using namespace std;

void validate (int);

int main (){
	
	int a=0, b=0;
	char x;
	
	cout<<"First input : ";
	cin>>a;
	validate (a);
	cout<<"Second input : ";
	cin>>b;
	validate (b);
	cout<<"Choose: '+' for 'Addition', '-' for 'Subtraction', '*' for 'Multiplication', '/' for 'Division' and '%' for 'Remainder'.\nOperation : ";
	cin>>x;
	
	int sum=b;
	int diff=a;
	int product=0;
	int quotient=0;
	int rem=a;
	
	switch (x) {
		case '+':
			for (int i=0; i<a; i++){
				sum++;
			}
			cout<<"Sum = "<<sum<<endl;
			break;
		case '-':
			for (int i=0; i<b; i++){
				diff--;
			}
			cout<<"Difference = "<<diff<<endl;
			break;
		case '*':
			for (int i=0; i<b; i++){
				for (int j=0; j<a; j++){
					product++;
				}
			}
			cout<<"Product = "<<product<<endl;
			break;
		case '/':
			while (rem>0){
				for (int i=0; i<b; i++){
					rem--;
				}
				quotient++;
			}
			if (rem<0){
				quotient--;
				}
			cout<<"Quotient = "<<quotient<<endl;
			break;
		case '%':
			while (rem>0){
				for (int i=0; i<b; i++){
					rem--;
				}	
			}
			if (rem<0){
				for (int i=0; i<b; i++){
					rem++;
				}
			}
			cout<<"Remainder = "<<rem<<endl;
			break;
	}
	return 0;
}

void validate (int valid){
	if (valid<0){
		cout<<"Please! enter positive values only.";
		exit(0);
	}
}