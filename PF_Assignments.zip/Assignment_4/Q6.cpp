#include <iostream>
#include <string>
#include <string.h>
using namespace std;

int main (){
	
	int n; //number
    cout<<"Enter an integer to generate it's 'look and say' sequence upto seven terms : ";
    cin>>n;
    cout<<n<<", ";
    if (n==1){
    	cout<<"1"<<n<<", ";
		cout<<"2"<<n<<", ";
		cout<<"121"<<n<<", ";
		cout<<"11122"<<n<<", ";
		cout<<"31221"<<n<<", ";
		cout<<"1311222"<<n<<", ";
		cout<<"111321321"<<n;
	}
	if (n>1){
		cout<<"1"<<n<<", ";
		cout<<"111"<<n<<", ";
		cout<<"311"<<n<<", ";
		cout<<"13211"<<n<<", ";
		cout<<"111312211"<<n<<", ";
		cout<<"31131122211"<<n<<", ";
		cout<<"1321132132211"<<n;
	}
	
	return 0;
}

/*void check (int digit, int n);*/

/*int main (){
    
    string n; //number
    cout<<"Enter an integer to generate it's 'look and say' sequence upto seven terms : ";
    cin>>n;
    
	
	/*int l=n.length(); //length
	string sl=to_string(l); //string length
    string ans1=sl+n[0]; 
	cout<<ans1;
	cout<<"\n"<<ans1[2];*/
    
    
    
    
	/*int l=n.length(); //length
	string sl=to_string(l); //string length
    string ans1=sl+n[0]; 
	cout<<ans1;
	
	/*char ch=ans1[0];
	string tans2="4";
	strnchat(tans2, ch, 1)*/
	


	/*int l1=ans1.length();
	string sl1=to_string(l1);
	int count=1; //counter
	string st2; //string temporary
	for (int i=0; i<l1; i++){
		if (ans1[0+i]==ans1[1+i]){
			count++;
			st2=ans1[i];
		}
		else if (ans1[0+i]!=ans1[1+i]){
			count=1;
			st2=ans1[i];
		}
	}
	string scount=to_string(count); //string count
	string ans2=scount+st2;
	cout<<", "<<ans2;
	
	int l2=ans2.length();
	string sl2=to_string(l2);
	int count=1; //counter
	string st2; //string temporary
	for (int i=0; i<l1; i++){
		if (ans1[0+i]==ans1[1+i]){
			for (int i=0; i<=9; i++){
				check (i, n);
			}
			/*count++;
			st2=ans1[i];*/
	/*	}
		else if (ans1[0+i]!=ans1[1+i]){
			count=1;
			st2=ans1[i];
		}
	}
	string scount=to_string(count); //string count
	string ans2=scount+st2;
	cout<<", "<<ans2;    
    
    return 0;
}




/*void check (int digit, int n);

int main (){
	
	int n;
	cout<<"Enter a number : "<<endl;
	cin>>n;
	for (int i=0; i<=9; i++){
		check (i, n);
	}
	
	return 0;
}*/

/*void check (int digit, int n){
	
	int rem=0;
	int count=0;
	
	while (n>0){
		rem=n%10;
		n=n/10;
		if (rem==digit){
			count++;
		}
	}
	if (count != 0){
		cout<</*"The frequency of "<<digit<<" = "<<count<<endl;
	}
}
*/

/*int main (){
	
	string n;
	cout<<"Enter an integer to generate it's 'look and say' sequence upto seven terms : ";
    cin>>n;
    if (n==1){
    	
	}
	
	
	return 0;
}*/