#include <iostream>
#include <iomanip>
using namespace std;

int main (){
	
	int n1,n2,n3,n4,n5;
	int dn1,dn2,dn3,dn4,dn5; //for difference according to graph i.e. for n1=8 -> dn1=10-8=2
	int y=10, x=1;
	cout<<"Enter five values : "<<endl;
	cin>>n1>>n2>>n3>>n4>>n5;
	dn1=10-n1;
	dn2=10-n2;
	dn3=10-n3;
	dn4=10-n4;
	dn5=10-n5;
	
	cout<<"\nBar Chart : \n\n";
	
	for (int i=1; i<=11; i++){	
		for (int j=1; j<=6; j++){
			if (i<11 && j==1){
				cout<<setw(2)<<setfill('0')<<y;
			}
			if (i==11 && j==1){
				cout<<"       ";
			}
			if (i==11 && j<6){
				cout<<x;
				x++;
			}
			if (i>dn1 && i<11 && j==2){
				cout<<"*";
			}
			else {
				cout<<" ";
			}
			if (i>dn2 && i<11 && j==3){
				cout<<"*";
			}
			else {
				cout<<" ";
			}
			if (i>dn3 && i<11 && j==4){
				cout<<"*";
			}
			else {
				cout<<" ";
			}
			if (i>dn4 && i<11 && j==5){
				cout<<"*";
			}
			else {
				cout<<" ";
			}
			if (i>dn5 && i<11 && j==6){
				cout<<"*";
			}
			else {
				cout<<" ";
			}
		}
		y--;
		cout<<endl;
	}
	return 0;
}