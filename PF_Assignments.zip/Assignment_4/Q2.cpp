#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

void validate (int a);

int main (){
	
	//Starting of Part (a)
	cout<<"Part a)\n";
	int n=0;
	cout<<"Enter diameter : ";
	cin>>n;
	validate (n);
	int rows=n; //total rows
	int columns=n; //total columns
	
	int c=(((n-3)/2)+1); //column number
	int r=(((n-3)/2)+1); //row number
	int t1=3; //t stands for temporary/additional/helping variables
	int t2=-1;
	int t3=2;
	
	//for upper portion
	for (int i=1; i<=((rows-3)/2); i++){
		for (int j=1; j<=columns; j++){
			if (i<r && j<c){
				cout<<".";
			}
			if (i<r && j>c+t2 && j<c+t1){ //(i<r1 && j>c1-1 && j<c1+3)
				cout<<"*";
			}
			if (i<r && j>c+t3){ //(i<r1 && j>c1+2)
				cout<<".";
			}
		}
		c=c-1;
		t1=t1+2;
		t3=t3+2;
		cout<<endl;
	}
	
	//for middle 3 rows
	for (int i=1; i<=3; i++){
		for (int j=1; j<=columns; j++){
			if (i==1 && j<n+1){
				cout<<"*";
			}
			if (i==2 && j<n+1){
				cout<<"*";
			}
			if (i==3 && j<n+1){
				cout<<"*";
			}
		}
		cout<<endl;
	}
	
	//for lower portion
	r=(((rows-3)/2)+3); //row number
	c=2; //column number
	t1=columns;
	t2=columns-1;
	for (int i=(((rows-3)/2)+4); i>(((rows-3)/2)+3) && i<=rows; i++){
		for (int j=1; j<=columns; j++){
			if (i>r && j<c){
				cout<<".";
			}
			if (i>r && j>=c && j<t1){
				cout<<"*";
			}
			if (i>r && j>t2){
				cout<<".";
			}
		}
		c=c+1;
		t1=t1-1;
		t2=t2-1;
		cout<<endl;
	}//Ending of Part (a)
	
	//Starting of Part (b)
	cout<<"\nPart b)\n";
	n;
	cout<<"Enter an integer : ";
	cin>>n;
	rows=n; //total rows
	columns=n; //total columns
	r=1; //row number
	c=1; //column number
	
	//for upper half
	for (int i=1; i<=rows; i++){
		for (int j=1; j<=columns; j++){
			int t=1; //t stands for temporary/additional/helping variables
			int t1=c+t;
			if (i==r && j<=c){
				cout<<"*";
			}
			if (t1%2==0){
			    while (t<=n){
				    if (i==r && j==c+t){
			    		cout<<"_";
		    		}
	    			t++;
    				if (i==r && j==c+t){
					    cout<<".";
				    }
			    	t++;
		    	}
			}
			if (t1%2==1){
    			while (t<=n){
				    if (i==r && j==c+t){
			    		cout<<".";
		    		}
	    			t++;
    				if (i==r && j==c+t){
					    cout<<"_";
				    }
				    t++;
			    }
			}
		}
		r=r+1;
		c=c+1;
		cout<<endl;
	}
	
	//for lower half
	rows=n-1;
	columns=n;
	r=1;
	c=n-1;
	for (int i=1; i<=rows; i++){
		for (int j=1; j<=columns; j++){
			int t=1;
			int t1=c+t;
			if (i==r && j<=c){
				cout<<"*";
			}
			if (t1%2==1){
			    while (t<=n){
				    if (i==r && j==c+t){
			    		cout<<"_";
		    		}
	    			t++;
    				if (i==r && j==c+t){
					    cout<<".";
				    }
			    	t++;
		    	}
			}
			if (t1%2==0){
    			while (t<=n){
				    if (i==r && j==c+t){
			    		cout<<".";
		    		}
	    			t++;
    				if (i==r && j==c+t){
					    cout<<"_";
				    }
				    t++;
			    }
			}
		}
		r=r+1;
		c--;
		cout<<endl;
	}
	//Ending of Part (b)
	return 0;
}

void validate (int a){
	
	if (a%2==0){
		cout<<"Please enter a valid input. Thank You!";
		exit(0);
	}
	
}