/* Name : Faraz Hayder
   Roll No. : I22-2687 */
#include <iostream>
#include <iomanip>
#include <string.h>
#include <bitset>
using namespace std;

void encrypt(char[]);
void decrypt(char[]);
string to_binary (int);

int main (){
	
	char charcoding[52];
	charcoding[0]='a';
	charcoding[1]='b';
	charcoding[2]='c';
	charcoding[3]='d';
	charcoding[4]='e';
	charcoding[5]='f';
	charcoding[6]='g';
	charcoding[7]='h';
	charcoding[8]='i';
	charcoding[9]='j';
	charcoding[10]='k';
	charcoding[11]='l';
	charcoding[12]='m';
	charcoding[13]='n';
	charcoding[14]='o';
	charcoding[15]='p';
	charcoding[16]='q';
	charcoding[17]='r';
	charcoding[18]='s';
	charcoding[19]='t';
	charcoding[20]='u';
	charcoding[21]='v';
	charcoding[22]='w';
	charcoding[23]='x';
	charcoding[24]='y';
	charcoding[25]='z';
	charcoding[26]='A';
	charcoding[27]='B';
	charcoding[28]='C';
	charcoding[29]='D';
	charcoding[30]='E';
	charcoding[31]='F';
	charcoding[32]='G';
	charcoding[33]='H';
	charcoding[34]='I';
	charcoding[35]='J';
	charcoding[36]='K';
	charcoding[37]='L';
	charcoding[38]='M';
	charcoding[39]='N';
	charcoding[40]='O';
	charcoding[41]='P';
	charcoding[42]='Q';
	charcoding[43]='R';
	charcoding[44]='S';
	charcoding[45]='T';
	charcoding[46]='U';
	charcoding[47]='V';
	charcoding[48]='W';
	charcoding[49]='X';
	charcoding[50]='Y';
	charcoding[51]='Z';
	
	encrypt(charcoding);
	decrypt(charcoding);
	
	return 0;
}

void encrypt(char charcoding[52]){
	
	string text="";
	const char spacestring[]=" ";
	cout<<"Enter text to be encrypted : ";
	getline(cin,text);
	int length=text.length();
	string tempcipher="";
	string ciphertext="";
	for (int i=0; i<length; i++){
		for (int j=0; j<52; j++){
			if (text[i]==charcoding[j]){
				if (j>=0 && j<26){
					int a=j+96;
					tempcipher=to_binary(a);
					ciphertext=ciphertext+tempcipher;
				}
				else if (j>=26 && j<52){
					int a=j+38;
					tempcipher=to_binary(a);
					ciphertext=ciphertext+tempcipher;
				}
			}
		}
		if (text[i]==spacestring[0]){
				ciphertext=ciphertext+" ";
			}
	}
	cout<<"Encrypted text : "<<ciphertext<<endl;
}

void decrypt (char charcoding[52]){
	
	string text="";
	const char spacestring[]=" ";
	cout<<"\nEnter text to be decrypted : ";
	getline(cin,text);
	int length=text.length();
	string tempdecipher="";
	string newtext="";
	string deciphertext="";
	int a=0,t=0;
	for (int i=0; i<=length; i++){
		newtext="";
		for (int j=0; j<5; j++){
			if (text[t]==spacestring[0]){
				newtext[0]=spacestring[0];
				j+=4;
				t++;
			}
			else {
				newtext=newtext+text[t];
				t++;
			}
		}
		if (newtext[0]==spacestring[0]){
			deciphertext=deciphertext+" ";
			i+=1;
		}
		else {
			for (int k=64; k<90; k++){
				tempdecipher=to_binary(k);
				if (newtext==tempdecipher){
					a=k-64;
					deciphertext=deciphertext+charcoding[a];
				}
			}
			i+=4;
		}
	}
	cout<<"Decrypted text : "<<deciphertext<<endl;
}

string to_binary (int a){
	
	string binary = bitset<5>(a).to_string();
	return binary;
}

	//Table
	/*int coding[52];
	coding[0]=00000;
	coding[1]=00001;
	coding[2]=00010;
	coding[3]=00011;
	coding[4]=00100;
	coding[5]=00101;
	coding[6]=00110;
	coding[7]=00111;
	coding[8]=01000;
	coding[9]=01001;
	coding[10]=01010;
	coding[11]=01011;
	coding[12]=01100;
	coding[13]=01101;
	coding[14]=01110;
	coding[15]=01111;
	coding[16]=10000;
	coding[17]=10001;
	coding[18]=10010;
	coding[19]=10011;
	coding[20]=10100;
	coding[21]=10101;
	coding[22]=10110;
	coding[23]=10111;
	coding[24]=11000;
	coding[25]=11001;
	coding[26]=00000;
	coding[27]=00001;
	coding[28]=00010;
	coding[29]=00011;
	coding[30]=00100;
	coding[31]=00101;
	coding[32]=00110;
	coding[33]=00111;
	coding[34]=01000;
	coding[35]=01001;
	coding[36]=01010;
	coding[37]=01011;
	coding[38]=01100;
	coding[39]=01101;
	coding[40]=01110;
	coding[41]=01111;
	coding[42]=10000;
	coding[43]=10001;
	coding[44]=10010;
	coding[45]=10011;
	coding[46]=10100;
	coding[47]=10101;
	coding[48]=10110;
	coding[49]=10111;
	coding[50]=11000;
	coding[51]=11001;*/
	
	//this is a sample text
	//10011001110100010010 0100010010 00000 100100000001100011110101100100 10011001001011110011
	