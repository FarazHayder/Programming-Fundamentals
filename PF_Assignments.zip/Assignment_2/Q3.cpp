#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main () {
	
	const int y=10, d=20;
	float x,c,v;
	cout<<"Enter value of: "<<endl<<"c= ";
	cin>>c;
	cout<<"v= ";
	cin>>v;
	x=(y-c)/(d+v); //solving the formula
	cout<<x;
	
	return 0;
}
