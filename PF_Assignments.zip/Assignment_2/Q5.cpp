#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	int yrs=0, months=0, days=0, dobd=0, dobm=0, doby=0;
	const int fyr=2022, fmonth=10, fday=1; //fixed set date
	cout<<"How old are you in terms of age in: "<<endl;
	cout<<"Years= ";
	cin>>yrs;
	cout<<"Months= ";
	cin>>months;
	cout<<"Days= ";
	cin>>days;
	
	if (yrs>=0 && months>=0 && days>=0){ //for positive values, program will countinue
		
		dobd=fday-days;	//updating value of days in date of birth
		if (dobd==-30){	//for when the input of days is 31
			dobd=dobd+61; //updating value of days in date of birth
			dobm=dobm-2; //updating value of months in date of birth
		}
		else if (dobd<0){ //for when the input of days is between 1 and 31
			dobd=30+dobd; //updating value of days in date of birth
			dobm=dobm-1; //updating value of months in date of birth
		}
		else if (dobd==0){ //for when the input of days is 1
			dobd=dobd+1; //updating value of days in date of birth
		}
		
		dobm=fmonth-months+dobm; //updating value of months in date of birth
		if (dobm<=0){ //for when the value of months is less than 10 i.e when the input of days is from 2 to 31 or input of months is greater than 10
			doby=doby-1; //updating value of years in date of birth
			dobm=12+dobm; //updating value of months in date of birth
		}
		doby=fyr-yrs+doby; //updating value of years in date of birth
		
		cout<<"You are "<<yrs<<" years, "<<months<<" months"<<" and "<<days<<" days old on 1st October, 2022."<<endl; //displaying age according to fixed set date
		cout<<"Your date of birth is: "<<setw(2)<<setfill('0')<<dobd<<"-"<<setw(2)<<setfill('0')<<dobm<<"-"<<doby; //displaying date of birth according to dd/mm/yyyy pattern
	}
	else if (yrs<0 || months<0 || days<0){ //for negative values, program will terminate
		cout<<"Please enter valid date. Thank You.";
	}
	
	return 0;
}
