#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	float hrs, rph, gp;
	cout<<"Enter the number of your work hours: ";
	cin>>hrs;
	cout<<"Enter rate per hour: ";
	cin>>rph;
	gp=(rph*40)+(1.5*rph*(hrs-40)); //calculating gross pay
	cout<<"Gross Pay = "<<gp;
	
	return 0;
}
