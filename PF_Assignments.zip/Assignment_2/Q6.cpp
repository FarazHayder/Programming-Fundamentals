#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	float s, v, t, a;
	cout<<"To compute the distance S, enter the values of: "<<endl;
	cout<<"initial velocity v= ";
	cin>>v;
	cout<<"time t= ";
	cin>>t;
	cout<<"acceleration a= ";
	cin>>a;
	s=v*t+(1.0/2)*a*t*t; //calculating distance
	cout<<"Distance S= "<<s;
	
	return 0;
}
