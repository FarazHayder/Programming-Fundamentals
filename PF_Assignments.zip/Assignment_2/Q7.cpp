#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

/* Name: Faraz Hayder | Roll Number: 2687 */

int main() {
	
	//box
	cout<<setw(10)<<"**********"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<setw(10)<<"**********"<<endl;
	
	//oval
	cout<<setw(7)<<"****"<<endl;
	cout<<setw(3)<<"*"<<setw(5)<<"*"<<endl;
	cout<<setw(2)<<"*"<<setw(7)<<"*"<<endl;
	cout<<setw(1)<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<"*"<<setw(9)<<"*"<<endl;
	cout<<setw(1)<<"*"<<setw(9)<<"*"<<endl;
	cout<<setw(2)<<"*"<<setw(7)<<"*"<<endl;
	cout<<setw(3)<<"*"<<setw(5)<<"*"<<endl;
	cout<<setw(7)<<"****"<<endl;
	
	//arrow
	cout<<setw(4)<<"/\\"<<endl;
	cout<<setw(2)<<"/"<<setw(3)<<"\\"<<endl;
	cout<<setw(5)<<"/____\\"<<endl;
	cout<<setw(4)<<"**"<<endl;
	cout<<setw(4)<<"**"<<endl;
	cout<<setw(4)<<"**"<<endl;
	cout<<setw(4)<<"**"<<endl;
	cout<<setw(4)<<"**"<<endl;
	cout<<setw(4)<<"**"<<endl;
	cout<<setw(4)<<"**"<<endl;
	
	//diamond
	cout<<setw(5)<<"*"<<endl;
	cout<<setw(4)<<"*"<<setw(2)<<"*"<<endl;
	cout<<setw(3)<<"*"<<setw(4)<<"*"<<endl;
	cout<<setw(2)<<"*"<<setw(6)<<"*"<<endl;
	cout<<setw(1)<<"*"<<setw(8)<<"*"<<endl;
	cout<<setw(2)<<"*"<<setw(6)<<"*"<<endl;
	cout<<setw(3)<<"*"<<setw(4)<<"*"<<endl;
	cout<<setw(4)<<"*"<<setw(2)<<"*"<<endl;
	cout<<setw(5)<<"*"<<endl;
	
	return 0;
}
