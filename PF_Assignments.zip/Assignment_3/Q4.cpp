/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
using namespace std;
bool validate (int num){
		
	if (num>0 and num<=3999){
		return true;
	}
	else {
		return false;
	}
}

int main (){
	
	int num, thousands, hundreds, tens, units, temp;
	bool numberRange;
	cout<<"Enter an integer between 0 and 4000 : ";
	cin>>num;
	numberRange=validate(num);
	if (numberRange==true){
		
		thousands = num/1000;
		temp = num%1000;
		hundreds = temp/100;
		temp = temp%100;
		tens = temp/10;
		temp = temp%10;
		units = temp/1;
		
		if (thousands==1){
			cout<<"M";
		}
		if (thousands==2){
			cout<<"MM";
		}
		if (thousands==3){
			cout<<"MMM";
		}	
			
		if (hundreds==1){
			cout<<"C";
		}
		if (hundreds==2){
			cout<<"CC";
		}
		if (hundreds==3){
			cout<<"CCC";
		}
		if (hundreds==4){
			cout<<"CD";
		}
		if (hundreds==5){
			cout<<"D";
		}
		if (hundreds==6){
			cout<<"DC";
		}
		if (hundreds==7){
			cout<<"DCC";
		}
		if (hundreds==8){
			cout<<"DCCC";
		}
		if (hundreds==9){
			cout<<"CM";
		}
	
		if (tens==1){
			cout<<"X";
		}
		if (tens==2){
			cout<<"XX";
		}
		if (tens==3){
			cout<<"XXX";
		}
		if (tens==4){
			cout<<"XL";
		}
		if (tens==5){
			cout<<"L";
		}
		if (tens==6){
			cout<<"LX";
		}
		if (tens==7){
			cout<<"LXX";
		}
		if (tens==8){
			cout<<"LXXX";
		}
		if (tens==9){
			cout<<"XC";
		}
			
		if (units==1){
			cout<<"I";
		}
		if (units==2){
			cout<<"II";
		}
		if (units==3){
			cout<<"III";
		}
		if (units==4){
			cout<<"IV";
		}
		if (units==5){
			cout<<"V";
		}
		if (units==6){
			cout<<"VI";
		}
		if (units==7){
			cout<<"VII";
		}
		if (units==8){
			cout<<"VIII";
		}
		if (units==9){
			cout<<"IX";
		}
	}
	else {
		cout<<"Invalid input.";
	}
	
	return 0;
	
}
