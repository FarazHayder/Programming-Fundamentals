/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
#include <string>
#include <cmath>
using namespace std;

int main (){
	
	string convertfrom, convertto;
	float value;
	cout<<"Enter the unit you want to convert from : ";
	cin>>convertfrom;
	cout<<"Enter the unit you want to convert to : ";
	cin>>convertto;
	cout<<"Enter value = ";
	cin>>value;
	if (convertfrom=="fl.oz" && convertto=="ml"){
		float ans;
		ans=value * 29.5735;
		cout<<value<<" fl.oz = "<<ans<<" ml ";
	}
	else if (convertfrom=="fl.oz" && convertto=="l"){
		float ans;
		ans=value * 0.0295735;
		cout<<value<<" fl.oz = "<<ans<<" l ";
	}
	else if (convertfrom=="gal" && convertto=="ml"){
		float ans;
		ans=value * 3785.41;
		cout<<value<<" gal = "<<ans<<" ml ";
	}
	else if (convertfrom=="gal" && convertto=="l"){
		float ans;
		ans=value * 3.78541;
		cout<<value<<" gal = "<<ans<<" l ";
	}
	else if (convertfrom=="oz" && convertto=="g"){
		float ans;
		ans=value * 28.3495;
		cout<<value<<" oz = "<<ans<<" g ";
	}
	else if (convertfrom=="oz" && convertto=="kg"){
		float ans;
		ans=value * 0.0283495;
		cout<<value<<" oz = "<<ans<<" kg ";
	}
	else if (convertfrom=="lb" && convertto=="g"){
		float ans;
		ans=value * 453.592;
		cout<<value<<" lb = "<<ans<<" g ";
	}
	else if (convertfrom=="lb" && convertto=="kg"){
		float ans;
		ans=value * 0.453592;
		cout<<value<<" lb = "<<ans<<" kg ";
	}
	else if (convertfrom=="in" && convertto=="mm"){
		float ans;
		ans=value * 25.4;
		cout<<value<<" in = "<<ans<<" mm ";
	}
	else if (convertfrom=="in" && convertto=="cm"){
		float ans;
		ans=value * 2.54;
		cout<<value<<" in = "<<ans<<" cm ";
	}
	else if (convertfrom=="in" && convertto=="m"){
		float ans;
		ans=value * 0.0254;
		cout<<value<<" in = "<<ans<<" m ";
	}
	else if (convertfrom=="in" && convertto=="km"){
		float ans;
		ans=value * 0.0000254;
		cout<<value<<" in = "<<ans<<" km ";
	}
	else if (convertfrom=="ft" && convertto=="mm"){
		float ans;
		ans=value * 304.8;
		cout<<value<<" ft = "<<ans<<" mm ";
	}
	else if (convertfrom=="ft" && convertto=="cm"){
		float ans;
		ans=value * 30.48;
		cout<<value<<" ft = "<<ans<<" cm ";
	}
	else if (convertfrom=="ft" && convertto=="m"){
		float ans;
		ans=value * 0.3048;
		cout<<value<<" ft = "<<ans<<" m ";
	}
	else if (convertfrom=="ft" && convertto=="km"){
		float ans;
		ans=value * 0.0003048;
		cout<<value<<" ft = "<<ans<<" km ";
	}
	else if (convertfrom=="mi" && convertto=="mm"){
		float ans;
		ans=value * 1609340;
		cout<<value<<" mi = "<<ans<<" mm ";
	}
	else if (convertfrom=="mi" && convertto=="cm"){
		float ans;
		ans=value * 160934;
		cout<<value<<" mi = "<<ans<<" cm ";
	}
	else if (convertfrom=="mi" && convertto=="m"){
		float ans;
		ans=value * 1609.34;
		cout<<value<<" mi = "<<ans<<" m ";
	}
	else if (convertfrom=="mi" && convertto=="km"){
		float ans;
		ans=value * 1.60934;
		cout<<value<<" mi = "<<ans<<" km ";
	}
	else {
		cout<<"Enter a valid conversion. Thank You.";
	}
	
	return 0;
}
