/* Name: Faraz Hayder | Roll Number: 2687 */
#include<iostream>
using namespace std;

void validate (void);
int getswitchstatus(void);
int getgearswitch(void);

 int main()
 {
  int cl,mus,gss,open1=0,open2=0;
  int dbr,dbl,inr,inl,outr,outl;
    cout<<"Enter dashboard status for right door (0 for not active and 1 for activate) : ";
    cin>>dbr;
    if((dbr!=0)&&(dbr!=1))
{
cout<<"Invalid input.";
}
    cout<<"Enter dashboard status for left door (0 for not active and 1 for activate ) : ";
    cin>>dbl;
    if((dbl!=0)&&(dbl!=1))
{
cout<<"Invalid input.";
}
    cout<<"Enter inside handle status for right door(0 for not active and 1 for activate ) : ";
    cin>>inr;
    if((inr!=0)&&(inr!=1))
{
cout<<"Invalid input.";
}
    cout<<"Enter inside handle status for left door(0 for not active and 1 for activate ) : ";
    cin>>inl;
    if((inl!=0)&&(inl!=1))
{
cout<<"Invalid input.";
}
    cout<<"Enter outside handle status for right door(0 for not active and 1 for activate ) : ";
    cin>>outr;
    if((outr!=0)&&(outr!=1))
{
cout<<"Invalid input.";
}
    cout<<"Enter outside handle status for left door(0 for not active and 1 for activate ) : ";
    cin>>outl;
    if((outl!=0)&&(outl!=1))
{
cout<<"Invalid input.";
}

  cout<<"Enter childlock status (0 for not active and 1 for activate ) : ";
  cin>>cl;
  if((cl!=0)&&(cl!=1))
  {
  cout<<"Invalid input.";
}
  mus=getswitchstatus();
  gss=getgearswitch();
  switch(mus)
  {
  case 0:
  open1=0;
  open2=0;
  break;
 
  case 1:
 
  if(gss==0)
  {
  open1=0;
  open2=0;
}
  else if(gss==1)
  {
     if(dbr==1)
     {
open1=1;

   }
else if(dbr==0)
{
if(outr==1)
{
 open1=1;
   }
   else if(outr==0)
   {
    if(cl==0)
    {
    if(inr==1)
    {
    open1=1;
}
}
}
   }
if(dbl==1)
     {
open2=1;
   }
else if(dbl==0)
{
if(outl==1)
{
 open2=1;
   }
   else if(outl==0)
   {
    if(cl==0)
    {
    if(inl==1)
    {
    open2=1;
}
}
}
   }  

}

break;
}
if((open1==0)&&(open2==0))
{
cout<<"Both doors remain closed";
}
else if((open1==1)&&(open2==1))
{
cout<<"Both doors will open.";
}
else if((open1==1)&&(open2==0))
{
cout<<"Only right door will open.";
}
else if((open1==0)&&(open2==1))
{
cout<<"Only Left door will open.";
}
return 0;
}

void validate(void)
{
cout<<"You have entered Invalid number. please enter valid number";
}

int getswitchstatus(void)
{
int mus;
cout<<"Enter master unlock status (0 for deactivated and 1 for activated) : ";
cin>>mus;
if(mus==0)
{
return 0;
}
else if(mus==1)
{
return 1;
}
else
{
cout<<"Invalid input.";
}
}

int getgearswitch(void)
 {
    char gss;
   
   
    cout<<"Enter Gear Shift Setting (P,N,D,R,1,2,3) : ";
    cin>>gss;
    if(gss=='P')
    {
    return 1;
}
else if((gss=='1')||(gss=='N')||(gss=='D')||(gss=='R')||(gss=='2')||(gss=='3'))
{
return 0;
}
else
{
cout<<"Invalid input.";
}
}
