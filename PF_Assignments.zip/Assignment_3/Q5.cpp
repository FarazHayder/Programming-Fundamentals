/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
#include <string>
using namespace std;

int main (){
	
	int taxFilerStatus, carType, optionalFeatures, floorMats, doorVisors, trunkTray, infotainmentSystem, navigationSystem, fogLights, Lights, highGradeInterior, Seats;
	float budget, sum;
	string filerstatus, cartype, floormats, doorvisors, trunktray, infotainmentsystem, navigationsystem, foglights, lights, highgradeinterior, seats;
	cout<<"Enter your budget : ";
	cin>>budget;
	cout<<"Enter your tax filer status : \nPress '1' for 'filer' and '0' for 'non-filer'."<<endl;
	cin>>taxFilerStatus;
	if (taxFilerStatus==1){
		taxFilerStatus=25000;
		filerstatus="Filer.";
	}
	else if (taxFilerStatus==0){
		taxFilerStatus=75000;
		filerstatus="Non-filer.";
	}
	cout<<"Choose car type : \nPress '1' for 'Manual' and '2' for 'Automatic'."<<endl;
	cin>>carType;
	if (carType==1){
		carType=3769000;
		cartype="Manual";
	}
	else if (carType==2){
		carType=3899000;
		cartype="Automatic";
	}
	cout<<"Would you like optional features in your car?\n Press '1' for 'Yes' and '0' for 'No'.";
	cin>>optionalFeatures;
	if (optionalFeatures==1){
		cout<<"Press '1' to 'include' the optional feature and '0' to 'exclude' the optional feature.\nChoose from the following features : \n";
		cout<<"Floor Mats : ";
		cin>>floorMats;
		if (floorMats==1){
			floorMats=60000;
			floormats="Yes";
		}
		else if (floorMats==0){
			floorMats=0;
			floormats="No";
		}
		cout<<"Door Visors : ";
		cin>>doorVisors;
		if (doorVisors==1){
			doorVisors=60000;
			doorvisors="Yes";
		}
		else if (doorVisors==0){
			doorVisors=0;
			doorvisors="No";
		}
		cout<<"Trunk Tray : ";
		cin>>trunkTray;
		if (trunkTray==1){
			trunkTray=8500;
			trunktray="Yes";
		}
		else if (trunkTray==0){
			trunkTray=0;
			trunktray="No";
		}
		cout<<"Infotainment System : ";
		cin>>infotainmentSystem;
		if (infotainmentSystem==1){
			infotainmentsystem="Yes";
			cout<<"Navigation System : ";
			cin>>navigationSystem;
			if (navigationSystem==1){
				navigationSystem=59500;
				navigationsystem="Yes";
			}
			else if (navigationSystem==0){
				navigationSystem=8000;
				navigationsystem="No";
			}
		}
		else if (infotainmentSystem==0){
			infotainmentSystem=0;
			infotainmentsystem="No";
		}
		cout<<"Fog Lights : ";
		cin>>fogLights;
		if (fogLights==1){
			foglights="Yes";
			cout<<"Lights (Press '1' for 'Halogen' and '2' for 'LED') : ";
			cin>>Lights;
			if (Lights==1){
				Lights=2000;
				lights="Halogen";
			}
			else if (Lights==2){
				Lights=5000;
				lights="LED";
			}
		}
		else if (fogLights==0){
			fogLights=0;
			foglights="No";
		}
		
		cout<<"High Grade Interior : ";
		cin>>highGradeInterior;
		if (highGradeInterior==1){
			highgradeinterior="Yes";
			cout<<"Seats (Press '1' for 'Leather Seats' and '2' for 'Sofa Seats') : ";
			cin>>Seats;
			if (Seats==1){
				Seats=45000;
				seats="Leather Seats";
			}
			else if (Seats==2){
				Seats=25000;
				seats="Sofa Seats";
			}
		}
		else if (highGradeInterior==0){
			highGradeInterior=0;
			highgradeinterior="No";
		}
		
		sum=carType+taxFilerStatus+floorMats+doorVisors+trunkTray+infotainmentSystem+navigationSystem+fogLights+Lights+highGradeInterior+Seats;
		cout<<"\n\nYour selected items are : "<<endl<<"Car type : "<<cartype<<endl<<"Floor Mats : "<<floormats<<endl<<"Door Visors : "<<doorvisors<<endl<<"Trunk Tray : "<<trunktray<<endl<<"Infotainment System : "<<infotainmentsystem<<endl;
		if (infotainmentSystem==1){
			cout<<"Navigation System : "<<navigationsystem<<endl;
		}
		cout<<"Fog Lights : "<<foglights<<endl;
		if (fogLights==1 && Lights==1){
			cout<<lights;
		}
		if (fogLights==1 && Lights==2){
			cout<<lights;
		}
		cout<<"High Grade Interior : "<<highgradeinterior<<endl;
		if (highGradeInterior==1 && Seats==1){
			cout<<seats;
		}
		if (highGradeInterior==1 && Seats==2){
			cout<<seats;
		}
		cout<<"Total budget = "<<budget<<endl<<"Tax Filer Status = "<<filerstatus<<endl;
		if (sum>budget){
			cout<<"Sorry! You cannot afford it.";
		}
		else if (sum<=budget){
			cout<<"You have a good taste, go for it!";
		}
	}
	else if (optionalFeatures==0){
		sum=carType+taxFilerStatus;
		cout<<"\n\nYour selected items are : "<<endl<<"Car type : "<<cartype<<endl<<"Total budget = "<<budget<<endl<<"Tax Filer Status = "<<filerstatus<<endl;
		if (sum>budget){
			cout<<"Sorry! You cannot afford it.";
		}
		else if (sum<=budget){
			cout<<"You have a good taste, go for it!";
		}
	}	
	return 0;
}
