/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

float packageA(float);
float packageB(float);
float packageC(float);
void savingA(float, float, float, float);
void savingB(float, float, float, float);
void savingC(float, float, float, float);

int main (){
	
	char package;
	cout<<"Enter package type 'A', 'B', or 'C' : "<<endl<<"Enter package type : ";
	cin>>package;
	int gbused;
	cout<<"Enter the number of GBs used : ";
	cin>> gbused;
	switch(package){
		case 'A':
			float billA, billB, billC;
			billA=packageA(gbused);
			billB=packageB(gbused);
			billC=packageC(gbused);
			cout<<"Bill = "<<billA<<endl;
			savingA(gbused, billA, billB, billC);
			break;
		case 'B':
			
			billA=packageA(gbused);
			billB=packageB(gbused);
			billC=packageC(gbused);
			cout<<"Bill = "<<billB<<endl;
			savingB(gbused, billA, billB, billC);
			break;
		case 'C':
			
			billA=packageA(gbused);
			billB=packageB(gbused);
			billC=packageC(gbused);
			cout<<"Bill = "<<billC<<endl;
			savingC(gbused, billA, billB, billC);
			break;
	}
	return 0;
}

float packageA(float gbused){
	
	float bill;
	if (gbused>2){
		bill = 100+((gbused-2)*307.2);
		return bill;
	}
	else {
		bill=100;
		return bill;
	}
}

float packageB(float gbused){
	
	float bill;
	if (gbused>5.5){
		bill = 250+((gbused-5.5)*204.8);
		return bill;
	}
	else {
		bill=250;
		return bill;
	}
}

float packageC(float gbused){
	
	int bill;
	bill=1000;
	return bill;
}

void savingA(float gbused, float billA, float billB, float billC){
	
	float diffAB=billA-billB;
	float diffAC=billA-billC;
	cout<<"By choosing package B, you would have saved "<<diffAB<<endl;
	cout<<"By choosing package C, you would have saved "<<diffAC;
}

void savingB(float gbused, float billA, float billB, float billC){
	
	float diffBA=billB-billA;
	float diffBC=billB-billC;
	cout<<"By choosing package B, you would have saved "<<diffBA<<endl;
	cout<<"By choosing package C, you would have saved "<<diffBC;
}

void savingC(float gbused, float billA, float billB, float billC){
	
	float diffCA=billC-billA;
	float diffCB=billC-billB;
	cout<<"By choosing package B, you would have saved "<<diffCA<<endl;
	cout<<"By choosing package C, you would have saved "<<diffCB;
}
