/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
#include <string>
using namespace std;

void networkStartValidator ();
bool isConnected ();
float availableBandwidth ();
void startApplication (float bandwidth, bool wifi);
void stopApplication ();
void error (string error);
char getFileType ();
string fileSaver ();
string location (char filetype);
void saveFile (string , string);
bool isFileSaved (string filename, float bandwidth, char filetype);
void sendMessage (string message);
void networkSend (string returnMessage, string filename);

int main (){
	
	networkStartValidator ();
	return 0;
}

void networkStartValidator (){
	
	bool wifi;
	wifi=isConnected ();
	if (wifi==true){
		float bandwidth;
		bandwidth=availableBandwidth ();
		if (bandwidth>20){
			startApplication (bandwidth, wifi);
		}
		else if (bandwidth<=20){
			string err="Your available network bandwidth must be greater than 20.\n";
			error (err);
		}
	}
	else if (wifi==false){
		string err="Make sure you have an active internet connection.";
		error (err);
	}
}

void error (string error){
	
	cout<<error;
}

bool isConnected (){
	
	bool ans;
	cout<<"Are you connected to a stable network?\nPress '1' for 'Yes' and '0' for 'No'.\n";
	cin>>ans;
	return ans;
}

float availableBandwidth (){
	
	float ans;
	cout<<"Enter the available network bandwidth : \n";
	cin>>ans;
	return ans;
}

void startApplication (float bandwidth, bool wifi){
	
	char filetype; string filename;
	filename=fileSaver ();
	filetype=getFileType ();
	bool isFileSave=isFileSaved (filename, bandwidth, filetype);
	if (bandwidth>10 && wifi!=0 && isFileSave!=0){
		string returnMessage;
		networkSend (returnMessage, filename);
	}
		
}

string fileSaver (){
	
	string ans;
	cout<<"Enter the name of your file.\n";
	cin>>ans;
	return ans;
}

char getFileType (){
	
	char ans, T, M, P, I;
	cout<<"Enter the type of your file.\nThe file types are; T = 'txt', M = 'mp4' and P = 'mp3'.\n";
	cin>>ans;
	if (ans==T || ans==M || ans==P){
		return ans;
	}
	else {
		ans=I;
		return ans;
	}
}

bool isFileSaved(string filename, float bandwidth, char filetype){
	
	if (bandwidth>5){
		
		string locatio;
		locatio=location(filetype);
		saveFile(locatio, filename);
		return 1;
	}
	else {
		string err="Available network bandwidth must be greater than 5 to save files.";
		error (err);
		return 0;
	}
}

string location (char filetype){
	
	char T, P, M, I;
	if (filetype==T){
		string ans= "Text files";
		return ans;
	}
	if (filetype==P){
		string ans= "Sound files";
		return ans;
	}
	if (filetype==M){
		string ans= "Video files";
		return ans;
	}
	if (filetype==I){
		string err="Please enter valid file type.";
		error (err);
	}
}

void saveFile (string locatio, string filename){
	
	cout<<filename<<" is saved in "<<locatio<<".";
}

void networkSend (string returnMessage, string filename){
	
	cout<<returnMessage;
}

