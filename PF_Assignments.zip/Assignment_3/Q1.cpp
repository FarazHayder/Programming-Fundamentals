/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
using namespace std;

int getdate ();
int gettime ();
void validate (int, int, int, int, int, int);
void isoverlapping (int, int, int, int, int, int);

int main (){
	
	int date1, date2, times1, times2, timee1, timee2;
	
	cout<<"Enter Date of 1st appointment"<<endl;
	date1 = getdate ();
	cout<<"Enter Date of 2nd appointment"<<endl;
	date2 = getdate ();
	cout<<"Enter start time of 1st appointment."<<endl;
	times1 = gettime ();
	cout<<"Enter start time of 2nd appointment."<<endl;
	times2 = gettime ();
	cout<<"Enter end time of 1st appointment."<<endl;
	timee1 = gettime ();
	cout<<"Enter end time of 2nd appointment."<<endl;
	timee2 = gettime ();
	
	validate (date1, date2, times1, times2, timee1, timee2);

	return 0;
}

int getdate (){
	
	int date;
	cout<<"Enter date : ";
	cin>>date;
	return date;
	
}

int gettime (){
	
	int time;
	cin>>time;
	return time;
	
}

void validate (int date1, int date2, int times1, int times2, int timee1, int timee2){
	
	if (date1>=0 && date1<=31 && date2>=0 && date2<=31 && times1>=0 && times1<=23 && times2>=0 && times2<=23 && timee1>=0 && timee1<=23 && timee2>=0 && timee2<=23){
			isoverlapping(date1, date2, times1, times2, timee1, timee2);
	}
	else {
		cout<<"Please enter the values between 0 to 31st for date and 0 to 23 hrs for time."<<endl;
	}
}

void isoverlapping (int date1, int date2, int times1, int times2, int timee1, int timee2){
	
	if (date1!=date2){
	cout<<"Appointments do not overlap.";
	}
	else if (date1==date2 && times2>times1 && times2<timee1){
		cout<<"Appointments overlap.";	
	}
	else if (date1==date2 && times2<times1 && times2<timee1){
		cout<<"Appointments overlap.";
	}
	else {
		cout<<"Appointments do not overlap.";
	}
}
