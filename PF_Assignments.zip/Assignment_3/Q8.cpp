/* Name: Faraz Hayder | Roll Number: 2687 */
#include <iostream>
using namespace std;

int validateAge (int day , int month , int year);
int validatePostalCode (string c);
int incomeCheck (int sal);

int main(){
	int year, month, day, age, Discount, pcode_c, inc, income;
	string postalcode, name; 
	Discount = 0;
	
	cout<<"Enter Name : "<<endl;
	cin>>name;
	
	cout<<"Enter your year of Birth in /yy format:"<<endl;
	cin>>year;
	cout<<"Enter your month of Birth in /mm format:"<<endl;
	cin>>month;
	cout<<"Enter your day of Birth in /dd format:"<<endl;
	cin>>day;
	
	age = validateAge (day,month,year);
	
	if (age == 1){
		Discount = 50;
	}
	
	
	cout<<"Enter postal code : "<<endl;
	cin>>postalcode;
	
	pcode_c = validatePostalCode(postalcode);
	
	if (pcode_c == 1){
		Discount = Discount + 20;
	}
	
	cout<<"Enter your Monthly Income:"<<endl;
	cin>>inc;
	
	income = incomeCheck(inc);
	
	if (income == 1){
		Discount = Discount + 90;
	}
	
	cout<<name<<" you are eligible for : "<<Discount<<"% Discount."<<endl;
	
return 0;}

int validateAge (int day , int month , int year){
	
	int w_y = 2022-year;
	
	if (month>10 && w_y ==22){
		return 1;
		}
	else{
		return 0;
	}
	
	
	if (month==10 && w_y == 22){
		if (day==23 || day > 23){
			return 1;
		}
	}	
	else {
		return 0;
	}
		
	
}

int validatePostalCode(string a){
	int  b, c;
	b= a.at(0) ;
	c= a.at(2) ;
	if ((b=='4')&& c=='3'){
		return 1;
	}
	if ((b=='4')&&(c=='3'||c=='5')){
		return 1;
	}
	
}

int incomeCheck (int sal){
	
	if (sal < 10000){
		return 1;
	}
}
